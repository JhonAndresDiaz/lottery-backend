package com.konex.lottery_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LotteryBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LotteryBackendApplication.class, args);
	}

}
