package com.konex.lottery_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LotteryBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
